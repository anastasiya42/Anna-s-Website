/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.NumberFormat;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import java.util.Arrays;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.*;


/**
 *
 * @author Zimmer
 */

public class FinalProject extends JFrame {
    //app variables
    private JTextField product;
    private JTextField cost;
    private JTextField salesTax;
    private JTextField totalField;
    private JTextField state;
    private JTextField taxPercentage;
    private JList message;
    //app constant
    private final double doubleConstant = 100.00;
    
    public FinalProject() {
        initComponents();
    }
    
    private void initComponents() {
        try {
            UIManager.setLookAndFeel(
            UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException |
                IllegalAccessException | UnsupportedLookAndFeelException e) {
            System.out.println(e);
        }
        
        setTitle("Product Total Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationByPlatform(true);

        product = new JTextField();
        cost = new JTextField();
        salesTax = new JTextField();
        totalField = new JTextField();
        state = new JTextField();
        taxPercentage = new JTextField();
        
        totalField.setEditable(false);
        taxPercentage.setEditable(false);
        
       
        Dimension dim = new Dimension(150, 20);
       product.setPreferredSize(dim);
       product.setMinimumSize(dim);
       cost.setPreferredSize(dim);
       cost.setMinimumSize(dim);
       salesTax.setPreferredSize(dim);
       salesTax.setMinimumSize(dim);
       totalField.setPreferredSize(dim);
       totalField.setMinimumSize(dim);
       state.setPreferredSize(dim);
       state.setMinimumSize(dim);
       taxPercentage.setPreferredSize(dim);
       taxPercentage.setMinimumSize(dim);
       
       JButton calculateButton = new JButton("Calculate");
       JButton exitButton = new JButton("Exit");
       JButton lookUpButton = new JButton("Sales Tax Look-up");
       
       calculateButton.addActionListener(e -> calculateButtonClicked());
       exitButton.addActionListener(e -> exitButtonClicked());
       lookUpButton.addActionListener(e -> lookUpButtonClicked());
       
       JPanel buttonPanel = new JPanel();
        buttonPanel.add(lookUpButton);
       buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
       buttonPanel.add(calculateButton);
       buttonPanel.add(exitButton);
       
      
       
       JPanel welcome = new JPanel();
       welcome.add(new JLabel("Welcome to the Total Price Calculator"));
       
      JPanel panel = new JPanel();
      //three functioning user input controls 
    
       panel.setLayout(new GridBagLayout());
       panel.add(new JLabel("Product Name:"), getConstraints(0, 0));
       panel.add(product, getConstraints(1, 0));
       panel.add(new JLabel("Price:"), getConstraints(0, 1));
       panel.add(cost, getConstraints(1, 1));
       panel.add(new JLabel("$"), getConstraints(2, 1));
       panel.add(new JLabel("Sales Tax Percentage:"), getConstraints(0, 2));
       panel.add(salesTax, getConstraints(1, 2));
       panel.add(new JLabel("%"), getConstraints(2, 2));
       panel.add(new JLabel("Total Cost:"), getConstraints(0, 3));
       panel.add(totalField, getConstraints(1, 3));
       
       
       add(welcome, BorderLayout.PAGE_START);
       add(panel, BorderLayout.CENTER);
       add(buttonPanel, BorderLayout.SOUTH);
       
       
       
       setSize(new Dimension(350, 250));
       setVisible(true);
    }
       
         private GridBagConstraints getConstraints(int x, int y) {
           GridBagConstraints c = new GridBagConstraints();
           c.anchor = GridBagConstraints.LINE_START;
           c.insets = new Insets(5, 5, 0, 5);
           c.gridx = x;
           c.gridy = y;
           return c;
       }
       private void calculateButtonClicked() {
         
        SwingValidator sv = new SwingValidator(this);
        //IF statement
        if (
            sv.isPresent(cost, "Cost") &&
            sv.isDouble(cost, "Cost") &&
            sv.isPresent(salesTax, "Sales Tax") &&
            sv.isDouble(salesTax, "Sales Tax")){
         
          double sales = Double.parseDouble(salesTax.getText());
           double costs = Double.parseDouble(cost.getText());
           
       
            double total = ((sales / doubleConstant) * costs) + costs;
          
         
           NumberFormat currency = NumberFormat.getCurrencyInstance();
           totalField.setText(currency.format(total));
           
         
           
       }
       }
       
       private void exitButtonClicked() {
           System.exit(0);
       }
       
      private void lookUpButtonClicked() {
      //Array and for loop
       State[] states = new State[1];
        states[0] = new State("Alabama: 9.14" + "\n" + "Alaska: 1.43"  + "\n" + "Arizona: 8.37"  + "\n" + "Arkansas: 9.43"  + "\n" + "California: 8.56"  + "\n" +   
                 "Colorado: 7.63"  + "\n" + "Connecticut: 6.35"  + "\n" + "Delaware: 0"  + "\n" + "Florida: 7.05"  + "\n" + "Georgia: 7.29"  + "\n" + "Hawaii: 4.41"  + "\n" + "Idaho: 6.03"  + "\n" +
                "Illinois: 8.74"  + "\n" + "Indiana: 7.00"  + "\n" + "Iowa: 6.82"  + "\n" + "Kansas: 6.82"  + "\n" + "Kentucky: 6.00"  + "\n" + "Louisana: 9.45"  + "\n" + "Maine: 5.50"  + "\n" + "Maryland: 6.00"  + "\n" + "Massachusetts: 6.25"  + "\n" + "Michigan: 6.00"  + "\n" + "Minnesota: 7.43"  + "\n" + "Mississippi: 7.07"  + "\n" + "Missouri: 8.13"  + "\n" + "Montana: 0"  + "\n" + "Nebraska: 6.85"  + "\n" + "Nevada: 8.14"  + "\n" + "Nebraska: 6.85"  + "\n" + 
                "Nevada: 6.85" + "\n" + "New Hampshire: 0" + "\n" + "New Jersey: 6.60" + "\n" + "New Mexico: 7.82" + "\n" + "New York: 8.49" + "\n" + "North Carolina: 6.97" + "\n" + "North Dakota: 6.85" + "\n" + "Ohio: 7.17" + "\n" + "Oklahoma: 8.92" + "\n" + "Oregon: 0" + "\n" + "Pennsylvania: 6.34" + "\n" + "Rhode Island: 7.00" + "\n" + "South Carolina: 7.43" + "\n" + "South Dakota: 6.40" + "\n" + "Tennessee: 9.47" + "\n" + "Texas: 8.19" + "\n" + "Utah: 6.94" + "\n" + "Vermont: 6.18" + "\n" +
                "Virginia: 5.65" + "\n" + "Washington: 9.17" + "\n" + "West Virginia: 6.39" + "\n" +"Wisconsin: 5.44" + "\n" + "Wyoming: 5.36");
          
        
        Arrays.sort(states);
        for (State c : states) {
            System.out.println(c.getstateName());
        
     
      
        String message = c.getstateName();
          String title = "Sales Tax by State";
          JTextArea textArea = new JTextArea(6, 25);
      textArea.setText(message);
      textArea.setEditable(false);
    
      JScrollPane scrollPane = new JScrollPane(textArea);
   
      JOptionPane.showMessageDialog(textArea, scrollPane, title, JOptionPane.INFORMATION_MESSAGE);
        }
      
      }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            JFrame frame = new FinalProject();
        });
    }
    }
    
