
package finalproject;


public class State implements Comparable {
    private String stateName;
    private String taxPercent;
   

    public State(String stateName) {
        this.stateName = stateName;
       
        
    }

    public void setstateName(String stateName) {
        this.stateName = stateName;
    }

    public String getstateName() {
        return stateName;
    }

    public void settaxPercent(String taxPercent) {
        this.taxPercent = taxPercent;
    }
    public String gettaxPercent() {
        return taxPercent;
    }

   
    @Override
    public int compareTo(Object o) {
        State c = (State) o;
        int sortResult = this.getstateName().compareToIgnoreCase(c.getstateName());
        if (sortResult < 0) {
            return -1;
        } else if (sortResult > 0) {
            return 1;
        }
        return 0;
    }
}