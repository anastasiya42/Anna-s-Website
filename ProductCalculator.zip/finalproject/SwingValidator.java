/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;
import java.awt.Component;
import javax.swing.JOptionPane;
import javax.swing.text.JTextComponent;
//error message code
public class SwingValidator {    
    private final Component parentComponent;
    
    public SwingValidator(Component parent) {
        this.parentComponent = parent;
    }
    
    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(parentComponent, message, 
                "Invalid Data", JOptionPane.ERROR_MESSAGE);
    }

    public boolean isPresent(JTextComponent c, String fieldName) {
        if (c.getText().isEmpty()) {
            showErrorDialog("Please input all required fields");
            c.requestFocusInWindow();
            return false;
        } else {
            return true;
        }
    }

    public boolean isDouble(JTextComponent c, String fieldName) {
        try {
            Double.parseDouble(c.getText());
            return true;
        } catch (NumberFormatException e) {
            showErrorDialog("Please enter a valid number");
            c.requestFocusInWindow();
            return false;
        }
    }
}